# __init__.py

# version of the rendseq package:
__version__ = "0.1.3"
